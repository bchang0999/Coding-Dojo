function myBirthYearFunc(){
    console.log("I was born in " + 1980);
} 
//"The console will log what year your born by using a variable to fill in the + x"




function myBirthYearFunc(birthyearinput){
    console.log("I was born in " + birthyearinput)
}
//"The console log will state "I was born in (birthyearinput)"
//"Example would look like "I was born in 1997"



function add(num1,num2){
    console.log("summing numbers!");
    console.log("num1 is: " + num1)
    console.log("num2 is: " + num2)
    var sum = num1 + num2;
    console.log(sum);
}
//My prediction would be the console log would state
// Summing Numbers! num1 is 10 num2 is 20 30